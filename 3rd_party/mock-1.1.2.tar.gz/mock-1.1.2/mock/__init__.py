from __future__ import absolute_import
import mock.mock as _mock
from mock.mock import *
__all__ = _mock.__all__
#import mock.mock as _mock
#for name in dir(_mock):
#  globals()[name] = getattr(_mock, name)
